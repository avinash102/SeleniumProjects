package BusinessComponent;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class BaseClass {
  public WebDriver driver = null;
  @Parameters({"browser","url"})
  @BeforeTest
  public void browserInit(String browser,String url){
	  if(browser.equalsIgnoreCase("chrome")){
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\Driver\\chromedriver.exe");
		  driver = new ChromeDriver();
	  }else {
		  System.setProperty("webdriver.ie.driver", "C:\\Users\\admin\\Desktop\\Driver\\IEDriverServer.exe");
		  driver = new InternetExplorerDriver();
	  }  
	  driver.manage().window().maximize();
	  driver.get(url);
	  driver.manage().timeouts().implicitlyWait(35, TimeUnit.SECONDS);  
  }
  
  public static String getCellValue(int i,int rowNo,int colNo)  {
	    String data= null;
	    	try {
				File file1 = new File("C:\\Users\\admin\\eclipse-workspace\\JavaQuestion\\Pedigree\\input.xlsx");
				FileInputStream fis = new FileInputStream(file1);
				XSSFWorkbook wb1 = new XSSFWorkbook(fis);
				Sheet s1 = wb1.getSheetAt(i);
				data = s1.getRow(rowNo).getCell(colNo).getStringCellValue();	
			} catch (IOException e) {
				e.printStackTrace();
			}	 
	       return data;  
  }  
  
 
  public static void putCellValue(int rowNum,int colNum,String value)  {
		try {
		    File file2 = new File("C:\\Users\\admin\\eclipse-workspace\\JavaQuestion\\Pedigree\\output.xlsx");
		    FileInputStream fis1 = new FileInputStream(file2);
		    XSSFWorkbook wb2 = new XSSFWorkbook(fis1);
			Sheet s2 = wb2.getSheetAt(0);
			s2.createRow(rowNum).createCell(colNum).setCellValue(value);
		    
			FileOutputStream fout= new FileOutputStream(file2);	
			wb2.write(fout);
			wb2.close();	
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}	
	}

   
}
