package Components;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PageObjects.Calculator;

public class Test1 extends BaseClass {
	@Test
	public void Demo() throws InterruptedException {
		
//		driver.findElement(By.xpath("//*[@id=\"main\"]/div[1]/div[2]/a")).click();
//		Thread.sleep(4000);

		Calculator cl = new Calculator(driver);
		cl.selectDeposite();
		Thread.sleep(2000);

		cl.depositAmount();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id='icicitools_loan_HomeLoanEMIInputPanel_0']")).click();

		String Maturity = cl.maturityValue();
		System.out.println(Maturity);

		String Interest = cl.interestValue();
		System.out.println(Interest);
		Thread.sleep(2000);
		
		cl.radioDays();
		Thread.sleep(2000);
		
		cl.numDays();
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id='icicitools_loan_HomeLoanEMIInputPanel_0']")).click();
		
		String Maturity10 = cl.maturityValue();
		System.out.println(Maturity10);

		String Interest10 = cl.interestValue();
		System.out.println(Interest10);
		Thread.sleep(4000);
	
		driver.switchTo().parentFrame();
		driver.switchTo().parentFrame();
		driver.switchTo().defaultContent();
		Thread.sleep(4000);
		
		Actions a = new Actions(driver);
		a.moveToElement(driver.findElement(By.xpath("//*[@id=\"main\"]/div[1]/div[2]/a"))).click().build().perform();
		Thread.sleep(4000);
       

	}

	@AfterTest
	public void CloseDriver() {
		
	}
}
