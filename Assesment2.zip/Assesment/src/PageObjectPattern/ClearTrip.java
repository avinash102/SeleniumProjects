package PageObjectPattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ClearTrip {
	
	WebDriver driver;
	public ClearTrip(WebDriver driver){
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(id="RoundTrip")
	 WebElement roundTripOption;
	
	@FindBy(id="FromTag")
	 WebElement From;
	
	@FindBy(id="ToTag")
	 WebElement to;

	public WebElement roundTrip() {
		return roundTripOption;
	}
	
	public void DeptFrom(String fromPlace) {
		   From.sendKeys(fromPlace);
	}



	public void DeptTo(String toPlace) {
		// TODO Auto-generated method stub
		   to.sendKeys(toPlace);
	}


  
}

