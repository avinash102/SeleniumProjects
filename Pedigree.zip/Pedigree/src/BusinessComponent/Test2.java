package BusinessComponent;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import PageObject1.pedigreeobject;

public class Test2 extends BaseClass {
  @Test
  public void Demo() throws IOException {
	  pedigreeobject po = new pedigreeobject(driver);
	  po.searchbuttonClick();
	  po.searchbuttonInfo();
	  
	  
	
	  //driver.findElement(By .xpath("//input[@name='search']")).sendKeys("dog");
	  String count  =  driver.findElement(By.cssSelector("span.ng-binding")).getText();
	  String[] s = count.split("[()]");
	  String ans = s[1];
	  
	  BaseClass.putCellValue(0,0,ans);
	  
	  driver.findElement(By.xpath("//div[@class='articles-result']/ul/li[2]")).click();
	  Set<String> ids = driver.getWindowHandles();
	  Iterator<String> its = ids.iterator();
	  String parentid = its.next();
	  String childid  = its.next();
	  driver.switchTo().window(childid);
	  System.out.println(driver.getTitle());
	  driver.findElement(By.xpath("//img[@id='Header_imgLogo']")).click();
	  
	  
	  TakesScreenshot ts = (TakesScreenshot) driver;
	  File src = ts.getScreenshotAs(OutputType.FILE);
	  FileUtils.copyFile(src, new File("C:\\Users\\admin\\eclipse-workspace\\JavaQuestion\\Pedigree\\Screenshot\\pedigree.png"));  
  }
}
