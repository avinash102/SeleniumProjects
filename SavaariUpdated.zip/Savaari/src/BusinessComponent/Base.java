package BusinessComponent;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class Base {
	public WebDriver driver = null;

	@Parameters({ "browserType", "Url" })
	@BeforeTest
	public void browserInit(String browser, String Urls) {

		if (browser.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\admin\\Desktop\\Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.get(Urls);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

	}

	public static String details(String s) throws IOException {
        String dat = null;
		try {
			Properties p = new Properties();
			FileInputStream fis = new FileInputStream("C:\\Users\\admin\\eclipse-workspace\\JavaQuestion\\Savaari\\datadriven.properties");
			p.load(fis);
			dat =  p.getProperty(s);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return dat;
	}
}
