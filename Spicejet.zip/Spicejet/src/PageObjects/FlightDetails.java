package PageObjects;

import org.testng.annotations.Test;

public class FlightDetails {
  @Test
  public void f() {
  }
}
