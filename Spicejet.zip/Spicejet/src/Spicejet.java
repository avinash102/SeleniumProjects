import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Spicejet {
	public static void main(String[] args) throws InterruptedException, IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com");
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		// Radio Button
		driver.findElement(By.cssSelector("input[value='RoundTrip']")).click();

		// DepartureFrom
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.xpath("//a[@value='CJB']")).click();

		// DepartureTo
		driver.findElement(By.xpath("(//a[@value='BLR'])[2]")).click();
		
		
		//Calendar
		//DepartDate
		List <WebElement> dates = driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']"));
		int count = driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']")).size();
		for (int i = 0; i < count ; i++) {
			String text = driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']")).get(i).getText();
			if(text.equalsIgnoreCase("4")){
				System.out.println(text);
				driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']")).get(i).click();
				break;
			}
		}
		
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='ctl00$mainContent$view_date2']")).click();	
		List <WebElement> dates1 = driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']"));
		int count1 = driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']")).size();
		for (int i = 0; i < count ; i++) {
			String text = driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']")).get(i).getText();
			if(text.equalsIgnoreCase("11")){
				System.out.println(text);
				driver.findElements(By.cssSelector("div[id='ui-datepicker-div'] td[data-handler='selectDay']")).get(i).click();
				break;
			}
		}
		
		
		//Passengers
		Thread.sleep(2000);
		driver.findElement(By.id("divpaxinfo")).click();
		WebDriverWait d = new WebDriverWait(driver,20);
		d.until(ExpectedConditions.visibilityOfElementLocated(By.id("divpaxinfo")));
		driver.findElement(By.id("hrefIncAdt")).click();
		driver.findElement(By.id("btnclosepaxoption")).click();
		
		//Currency
		Select s = new Select(driver.findElement(By.name("ctl00$mainContent$DropDownListCurrency")));
               s.selectByValue("USD");
        
        driver.findElement(By.xpath("//input[@type='submit']")).click();
        
        
        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(src, new  File("./Screenshot/FlightDetails.png"));
        
        WebElement ModifySearch = driver.findElement(By.className("trip-modify-btn"));
        if(ModifySearch.isDisplayed()) {
        	System.out.println("We are on right page");
        	String DepatutureTime = driver.findElement(By.xpath("//table[@id='availabilityTable0']/tbody/tr[4]/td/span/div")).getText();
            System.out.println(DepatutureTime);
        }else {
        	System.out.println("We are on Wrong page");
        }
        
       String DepatutureTime = driver.findElement(By.xpath("//table[@id='availabilityTable0']/tbody/tr[4]/td/span/div")).getText();
       System.out.println(DepatutureTime);
        
	}

}
