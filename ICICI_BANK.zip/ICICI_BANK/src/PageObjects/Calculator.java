package PageObjects;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import Components.BaseClass;

public class Calculator extends BaseClass {
	
	public Calculator(WebDriver driver) {
		driver.switchTo().frame(driver.findElement(By.id("paymframe")));
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(xpath="//*[@id='ddlTypeOfFixedDeposit']")
	WebElement FixedDeposit;
	
	@FindBy(id="loanAmount")
	WebElement Amount;
	
	@FindBy(xpath="//*[@id='hdMaturityValue']")
	WebElement MaturityValue1;
	
	@FindBy(xpath="//*[@id='hdAIAmount']")
	WebElement Interest1;
	
	@FindBy(xpath="//*[@id='idDays']")
	WebElement Days;
	
	@FindBy(xpath="//*[@id='tenureDay']")
	WebElement DaysCount;
	
	public void selectDeposite() {
		 Select s = new Select(FixedDeposit);
		 s.selectByVisibleText(BaseClass.Data("Deposit"));
	}
	
	public void depositAmount() {
		Amount.clear();
 		Amount.sendKeys(BaseClass.Data("Amount"));
	}
	
	public String maturityValue() {
		String m = MaturityValue1.getAttribute("value");
		return m;
	}
	
	public String interestValue() {
		String i = Interest1.getAttribute("value");
		return i;
	}
	
	public void radioDays() {
		Days.click();
	}
	
	public void numDays() {
		DaysCount.clear();
		DaysCount.sendKeys("1000");
	}
	
	
	

	
	

	
}
