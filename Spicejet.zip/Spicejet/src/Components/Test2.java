package Components;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import PageObjects.SpiceTrip;

public class Test2 extends BaseClass{
  @Test
  public void Demo() {
	  try {
		  SpiceTrip sp = new SpiceTrip(driver); 
		  sp.roundTrip().click();
//		  sp.departureClick().click();
//		  sp.departureState().click();
//		  sp.departureto().click();
//		  sp.passenger().click(); 
//		   
		  
		  
		  
		  
//		  WebDriverWait d = new WebDriverWait(driver,20);
//		  d.until(ExpectedConditions.visibilityOfElementLocated(By.id("divpaxinfo")));
//		  
		  
	  }catch(Exception e) {
		  System.out.println(e.toString());
	  }    
  }
}
