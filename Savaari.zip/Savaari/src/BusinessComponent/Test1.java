package BusinessComponent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Test1 extends Base{
  @Test
  public void Demo() throws InterruptedException {
	driver.findElement(By.xpath("//label[@for='oneway_radio']/span")).click();
	Thread.sleep(2000);
	WebElement DeptFrom=driver.findElement(By.xpath("//input[@id='fromCityList']"));
	DeptFrom.sendKeys("Coimbatore, TN");
	Thread.sleep(2000);
	
	WebElement ToFrom= driver.findElement(By.xpath("//input[@placeholder='Start typing city - e.g. Mysore']"));
	ToFrom.sendKeys("Aurangabad, Maharashtra");
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//input[@placeholder=\"dd-mm-yyyy\"]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/div[1]/div/p-calendar[1]/span/div/table/tbody/tr[4]/td[4]/a")).click();
	Thread.sleep(2000); 
	
	WebElement Times = driver.findElement(By.xpath("//select[@id='pickUpTime']")); 
	Times.click();
	Select s = new Select(Times);
	s.selectByVisibleText("2:00 AM");
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//button[@type='button']")).click();
	
  }
  
  @AfterTest
  public void CloseDriver() throws InterruptedException{
	  Thread.sleep(5000);
	  driver.close();
  }
  

  
}
