package Components;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class BaseClass {
	public WebDriver driver = null;

	@Parameters({ "browserType", "url" })
	@BeforeTest
	public void browserInit(String browser, String Urls) {
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\admin\\Desktop\\Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.get(Urls);
		driver.manage().timeouts().implicitlyWait(35, TimeUnit.SECONDS);
	}

	public static String Data(String key) {
		String dat = null;
		try {
			Properties prop = new Properties();
			File file = new File("C:\\Users\\admin\\avinashProject\\ICICI_BANK\\datadriven.properties");
			FileInputStream fi = new FileInputStream(file);
			prop.load(fi);
			dat = prop.getProperty(key);
		} catch (Exception e) {
			System.out.println(e.toString());
		}	
		return dat;
	}

}
