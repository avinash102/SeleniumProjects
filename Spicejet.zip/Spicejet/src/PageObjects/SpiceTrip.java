package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SpiceTrip {
	
	WebDriver driver;
	
	public SpiceTrip(WebDriver driver){
		PageFactory.initElements(driver, this);
	}
	
	//*[@id="ctl00_mainContent_rbtnl_Trip_1"]
	
	@FindBy(xpath="//input[@value='RoundTrip']")
     WebElement RoundTripOption;
	
	public WebElement roundTrip(){
    	return RoundTripOption;
     }
	
	
	
	
	
	
	
	
	
	
	@FindBy(id="ctl00_mainContent_ddl_originStation1_CTXT")
    WebElement Departure;
	
	@FindBy(xpath="//a[@value='CJB']")
    WebElement DepartureState;
	
	@FindBy(xpath="(//a[@value='BLR'])[2]")
    WebElement Departureto;
	
	@FindBy(id="divpaxinfo")
    WebElement PassengerClick;
	
	
	
     
     
     public WebElement departureClick(){
     	return Departure;
      }
     
     public WebElement departureState(){
     	return DepartureState;
      }
     
     public WebElement departureto(){
      	return Departureto;
       }
     
     public WebElement passenger(){
       	return PassengerClick;
        }



}