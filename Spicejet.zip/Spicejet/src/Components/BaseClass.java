package Components;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

public class BaseClass {
	public WebDriver driver = null;

	@Parameters({ "browserType", "Url" })
	@BeforeTest
	public void preconditions(String browser, String Urls) {
		if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Desktop\\Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\admin\\Desktop\\Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		driver.get(Urls);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

	}

	
	public static String getCellValue(int sheetIndex, int rowNo, int colNum) {
		String data = null;
		try {
			File file = new File("C:\\Users\\admin\\avinashProject\\Assesment\\Excel\\Sel1.xlsx");
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			Sheet sheet = wb.getSheetAt(0);
			data = sheet.getRow(rowNo).getCell(colNum).getStringCellValue();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return data;
	}
	
	
}
