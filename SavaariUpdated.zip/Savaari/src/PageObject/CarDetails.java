package PageObject;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BusinessComponent.Base;

public class CarDetails {

	private WebDriver driver;

	public CarDetails(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);;
	}

	@FindBy(xpath="//label[@for='out_radio']/span")
	 WebElement  RoundTrip;
	
	@FindBy(xpath="//input[@id='fromCityList']")
	 WebElement  DeptFrom;
	
	public void RoundTripClick() {
		RoundTrip.click();
	}
	public void DepartureDest() throws IOException, InterruptedException {
		DeptFrom.clear();
		DeptFrom.sendKeys(Base.details("Departure"));
		Thread.sleep(2000);
		DeptFrom.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
	}
	

}
