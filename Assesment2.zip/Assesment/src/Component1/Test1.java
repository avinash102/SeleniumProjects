package Component1;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;
import PageObjectPattern.ClearTrip;

public class Test1 extends Base {
	@Test
	public void demo() {
		try {
			driver.switchTo().frame(0);
			ClearTrip trip = new ClearTrip(driver);
			trip.roundTrip().click();
			trip.DeptFrom(Base.getCellValue(0, 0, 0));
			trip.DeptTo(Base.getCellValue(0, 0, 1));
			TakesScreenshot ts = (TakesScreenshot)driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
		    FileUtils.copyFile(src, new File("./Screenshots/ClearTrip.png"));
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}

	}
}
