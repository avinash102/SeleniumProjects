package BusinessComponent;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import PageObject.CarDetails;

public class Test1 extends Base{
  @Test
  public void Demo() throws InterruptedException, IOException {
	  
	CarDetails cd  = new CarDetails(driver);  
	cd.RoundTripClick();
	cd.DepartureDest();  
	
	WebElement ToFrom= driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[2]/div[2]/input"));
	ToFrom.clear();
	ToFrom.sendKeys(Base.details("To"));
	Thread.sleep(4000);
	ToFrom.sendKeys(Keys.ENTER);
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//input[@placeholder=\"dd-mm-yyyy\"]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[3]/div[1]/div/p-calendar[1]/span/div/table/tbody/tr[4]/td[4]/a")).click();
	Thread.sleep(2000); 
	
	WebElement Times = driver.findElement(By.xpath("//select[@id='pickUpTime']")); 
	Times.click();
	Select s = new Select(Times);
	s.selectByVisibleText("2:00 AM");
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-home/div[1]/div[2]/div[2]/app-outstation/div/form/div[4]/div/div[1]/button")).click();
	Thread.sleep(5000);
	
	String minPrice = driver.findElement(By.xpath("//*[@id=\"approot\"]/mat-sidenav-container/mat-sidenav-content/app-select-car/div[2]/div/div/div[1]/div[3]/div[2]/span")).getText();
	String s1 = minPrice.substring(2);
	System.out.println(s1);
  }
  
  @AfterTest
  public void CloseDriver() throws InterruptedException{
	  Thread.sleep(5000);
	  
  }
  

  
}
