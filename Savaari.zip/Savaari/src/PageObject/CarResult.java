package PageObject;

public class CarResult {

}
