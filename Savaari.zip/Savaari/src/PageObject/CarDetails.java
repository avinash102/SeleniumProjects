package PageObject;

public class CarDetails {

}
