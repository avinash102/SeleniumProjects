package PageObject1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import BusinessComponent.BaseClass;

public class pedigreeobject {

	public pedigreeobject(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	 
	@FindBy(xpath="//div[@class='search']/div/a")
	WebElement searchButton;
	
	@FindBy(xpath="//input[@name='search']")
	WebElement searchButtonText;
	
	public void searchbuttonClick(){
		searchButton.click();
	}
	
	public void searchbuttonInfo(){
		 searchButtonText.sendKeys(BaseClass.getCellValue(0, 0, 0));
	}
	
      
}
